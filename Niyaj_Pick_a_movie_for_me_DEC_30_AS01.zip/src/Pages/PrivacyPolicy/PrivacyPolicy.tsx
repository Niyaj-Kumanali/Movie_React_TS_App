import './PrivacyPolicy.css';
const PrivacyPolicy = () => {
  return <div>PrivacyPolicy</div>;
};

export default PrivacyPolicy;
